package com.example.windcharge.client;

import com.example.windcharge.WindChargeMod;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = WindChargeMod.MODID, value = Side.CLIENT)
public class ClientProxy {
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(
            WindChargeMod.WIND_CHARGE, 0,
            new ModelResourceLocation(WindChargeMod.MODID + ":wind_charge", "inventory")
        );
    }
}
