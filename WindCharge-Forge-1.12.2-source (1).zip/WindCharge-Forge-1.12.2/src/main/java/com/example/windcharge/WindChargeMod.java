package com.example.windcharge;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.event.RegistryEvent;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;

@Mod(modid = WindChargeMod.MODID, name = WindChargeMod.NAME, version = WindChargeMod.VERSION)
@EventBusSubscriber(modid = WindChargeMod.MODID)
public class WindChargeMod {
    public static final String MODID = "windcharge";
    public static final String NAME = "WindCharge";
    public static final String VERSION = "1.0.0";

    public static Item WIND_CHARGE;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Recipe and item models are loaded from the resources folder.
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        WIND_CHARGE = new WindChargeItem();
        WIND_CHARGE.setRegistryName(new ResourceLocation(MODID, "wind_charge"));
        WIND_CHARGE.setUnlocalizedName(MODID + ".wind_charge");
        WIND_CHARGE.setCreativeTab(net.minecraft.creativetab.CreativeTabs.COMBAT);
        event.getRegistry().register(WIND_CHARGE);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.world.isRemote) return;
        int ticks = event.player.getEntityData().getInteger("WindChargeFallProtection");
        if (ticks > 0) {
            event.player.getEntityData().setInteger("WindChargeFallProtection", ticks - 1);
        }
    }

    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        if (event.getEntityLiving() instanceof net.minecraft.entity.player.EntityPlayer) {
            net.minecraft.entity.player.EntityPlayer player =
                (net.minecraft.entity.player.EntityPlayer) event.getEntityLiving();
            if (player.getEntityData().getInteger("WindChargeFallProtection") > 0) {
                event.setCanceled(true);
                player.fallDistance = 0.0F;
            }
        }
    }
}
