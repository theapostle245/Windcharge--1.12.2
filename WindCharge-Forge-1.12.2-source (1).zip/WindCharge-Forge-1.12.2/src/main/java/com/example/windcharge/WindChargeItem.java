package com.example.windcharge;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;

public class WindChargeItem extends Item {
    public WindChargeItem() {
        setMaxStackSize(16);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);

        if (!player.getCooldownTracker().hasCooldown(this)) {
            if (!world.isRemote) {
                // A strong upward impulse; modestly preserves existing horizontal movement.
                player.motionY = 1.15D;
                player.velocityChanged = true;
                player.fallDistance = 0.0F;
                player.getEntityData().setInteger("WindChargeFallProtection", 100);

                world.playSound(null, player.posX, player.posY, player.posZ,
                    SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 1.25F);
            }

            player.getCooldownTracker().setCooldown(this, 20);
            if (!player.capabilities.isCreativeMode) {
                stack.shrink(1);
            }
        }

        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }
}
