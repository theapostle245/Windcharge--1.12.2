# WindCharge — Minecraft Forge 1.12.2

This is a source project backport starter based on the behavior requested in chat.
It is **not a precompiled or tested JAR**. Build it with Java 8 and the included
ForgeGradle 2.3 setup, then test it in a Forge 1.12.2 client/server.

## Build
1. Install a Java 8 JDK.
2. Install Gradle 4.9 (or use a compatible Gradle wrapper if you add one).
3. Run `gradle setupDecompWorkspace`.
4. Run `gradle build`.
5. The JAR should appear in `build/libs/`.

## Item
Registry name: `windcharge:wind_charge`
Recipe: four gunpowder around a feather (shaped 2x2 pattern is defined in JSON).
Right-click launches the player, plays the vanilla explosion sound, applies a
short cooldown, and grants temporary fall-damage protection.

The texture is a placeholder; replace `assets/windcharge/textures/items/wind_charge.png`
with your original texture if desired.
